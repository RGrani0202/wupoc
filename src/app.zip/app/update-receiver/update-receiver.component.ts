import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import{ ReceiversService} from "../services/receivers.service";

@Component({
  selector: 'app-update-receiver',
  templateUrl: './update-receiver.component.html',
  styleUrls: ['./update-receiver.component.css']
})
export class UpdateReceiverComponent implements OnInit {
  receiverById:any={};

  constructor(private route: Router, private router:ActivatedRoute, private receiver:ReceiversService) { }
  
  ngOnInit(): void {
    console.log( this.router.snapshot.params.id);
    this.receiver.getReceiverById(this.router.snapshot.params.id)
    .subscribe((result:any)=>{
      this.receiverById=result;
      console.log(result.id);
      

    })
  }
  update(data:any){
    console.log("new form data ", data);
    this.receiver.updateReceiverById(this.router.snapshot.params.id,data)
    .subscribe((result)=>{
      console.log(result);
      alert("receiver updated !");
      this.route.navigate(['/my-receivers']);
      

    })

  }

}
