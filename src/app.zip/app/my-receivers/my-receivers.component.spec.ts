import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyReceiversComponent } from './my-receivers.component';

describe('MyReceiversComponent', () => {
  let component: MyReceiversComponent;
  let fixture: ComponentFixture<MyReceiversComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyReceiversComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyReceiversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
